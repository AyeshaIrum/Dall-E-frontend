import React from "react";
import { BrowserRouter, Route, Link, Routes } from "react-router-dom";
import { logo } from "./assets";
import { Home, CreatePost } from "./pages";

const App = () => {
  return (
    <BrowserRouter>
      <header className="w-full flex justify-between items-center bg-white sm:px-8 px-4 py-4 broder-b border-b-[#e6ebf4]">
        <Link to="/Dall-E-FrontEnd/">
          <img src={logo} alt="Logo" className="w-28 object-contain" />
        </Link>
        <Link
          to="/create-post"
          className="text-white font-inter font-medium bg-[#6469ff] px-4 py-2 rounded-md"
        >
          Create
        </Link>
      </header>
      <main className="sm:p-8 px-4 py-8 w-full bg-[#f9fafe] min-h-[calc(100vh-73px)]">
        <Routes>
          <Route path="/Dall-E-FrontEnd/" element={<Home />} />
          <Route path="/create-post" element={<CreatePost />} />
        </Routes>
      </main>
    </BrowserRouter>
  );
};

export default App;
